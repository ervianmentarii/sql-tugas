-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: Project_uber
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device` (
  `device_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `device_type` varchar(200) NOT NULL DEFAULT 'N/A',
  `os_version` varchar(200) NOT NULL DEFAULT 'N/A',
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`device_id`),
  KEY `Fk_user_id_device` (`user_id`),
  CONSTRAINT `Fk_user_id_device` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
INSERT INTO `device` VALUES (1,1,'Android','11','2025-06-01 08:00:00'),(2,2,'iOS','14','2025-06-01 09:00:00'),(3,3,'Android','10','2025-06-02 10:00:00'),(4,4,'iOS','13','2025-06-02 11:00:00'),(5,5,'Android','12','2025-06-03 12:00:00'),(6,6,'Android','11','2025-06-04 13:00:00'),(7,7,'iOS','14','2025-06-05 14:00:00'),(8,8,'Android','9','2025-06-06 15:00:00'),(9,9,'iOS','13','2025-06-07 16:00:00'),(10,10,'Android','10','2025-06-08 17:00:00'),(11,11,'iOS','12','2025-06-09 18:00:00'),(12,12,'Android','8','2025-06-10 19:00:00'),(13,13,'Android','7','2025-06-11 20:00:00'),(14,14,'iOS','15','2025-06-12 21:00:00'),(15,15,'Android','6','2025-06-13 22:00:00'),(16,16,'iOS','14','2025-06-14 23:00:00'),(17,17,'Android','9','2025-06-15 08:00:00'),(18,18,'iOS','13','2025-06-16 09:00:00'),(19,19,'Android','10','2025-06-17 10:00:00'),(20,20,'iOS','14','2025-06-18 11:00:00');
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver` (
  `driver_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `no_telp_driver` varchar(200) NOT NULL DEFAULT 'N/A',
  `lokasi_driver` varchar(200) NOT NULL DEFAULT 'N/A',
  PRIMARY KEY (`driver_id`),
  UNIQUE KEY `no_telp_driver` (`no_telp_driver`),
  KEY `Fk_user_id_driver` (`user_id`),
  CONSTRAINT `Fk_user_id_driver` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver`
--

LOCK TABLES `driver` WRITE;
/*!40000 ALTER TABLE `driver` DISABLE KEYS */;
INSERT INTO `driver` VALUES (1,1,'(0210) 609 5718','Pangkalpinang'),(2,2,'+62 821 9892 2016','Tangerang'),(3,3,'+62 192-513-6228','Tarakan'),(4,4,'(0357) 987 2279','Banjarbaru'),(5,5,'+62 813-2211-4455','Padang'),(6,6,'+62 813-2211-4456','Padang'),(7,7,'0812-3344-5566','Makasar'),(8,8,'(0274) 223 9941','Yogyakarta'),(9,9,'+62 812-9876-1234','Surabaya'),(10,10,'0853-9876-1234','Medan'),(11,11,'0812-9988-7766','Malang'),(12,12,'0822-3344-5566','Pekanbaru'),(13,13,'0852-1122-3344','Batam'),(14,14,'0813-6677-8899','Padang'),(15,15,'0813-6677-8898','Denpasar'),(16,16,'0878-5566-7788','Banjarmasin'),(17,17,'0856-9988-1122','Manado'),(18,18,'0881-4455-6677','Tangerang'),(19,19,'0814-7788-9900','Cirebon'),(20,20,'0833-5566-7788','Bogor');
/*!40000 ALTER TABLE `driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driveravailability`
--

DROP TABLE IF EXISTS `driveravailability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `driveravailability` (
  `availability_id` int NOT NULL AUTO_INCREMENT,
  `driver_id` int NOT NULL,
  `status` enum('aktif','tidak') NOT NULL DEFAULT 'aktif',
  `waktu` timestamp NOT NULL,
  PRIMARY KEY (`availability_id`),
  KEY `Fk_user_id_driveravailability` (`driver_id`),
  CONSTRAINT `Fk_user_id_driveravailability` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driveravailability`
--

LOCK TABLES `driveravailability` WRITE;
/*!40000 ALTER TABLE `driveravailability` DISABLE KEYS */;
INSERT INTO `driveravailability` VALUES (1,1,'aktif','2025-06-29 01:00:00'),(2,2,'tidak','2025-06-29 01:10:00'),(3,3,'aktif','2025-06-29 01:15:00'),(4,4,'aktif','2025-06-29 01:20:00'),(5,5,'tidak','2025-06-29 01:25:00'),(6,1,'tidak','2025-06-29 02:00:00'),(7,2,'aktif','2025-06-29 02:05:00'),(8,3,'tidak','2025-06-29 02:10:00'),(9,4,'aktif','2025-06-29 02:15:00'),(10,5,'aktif','2025-06-29 02:20:00'),(11,1,'aktif','2025-06-29 03:00:00'),(12,2,'aktif','2025-06-29 03:10:00'),(13,3,'aktif','2025-06-29 03:20:00'),(14,4,'tidak','2025-06-29 03:30:00'),(15,5,'tidak','2025-06-29 03:35:00'),(16,1,'aktif','2025-06-29 04:00:00'),(17,2,'tidak','2025-06-29 04:05:00'),(18,3,'aktif','2025-06-29 04:10:00'),(19,4,'aktif','2025-06-29 04:15:00'),(20,5,'aktif','2025-06-29 04:20:00');
/*!40000 ALTER TABLE `driveravailability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `feedback_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `submitted_at` datetime NOT NULL,
  `feedback_text` text,
  `response_status` enum('dijawab','belum') NOT NULL DEFAULT 'belum',
  PRIMARY KEY (`feedback_id`),
  KEY `Fk_user_id_feedback` (`user_id`),
  CONSTRAINT `Fk_user_id_feedback` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,1,'2025-06-29 23:02:32','Aplikasi bagus','dijawab'),(2,2,'2025-06-29 23:02:32','Driver ramah','belum'),(3,3,'2025-06-29 23:02:32','Harga terlalu mahal','dijawab'),(4,4,'2025-06-29 23:02:32','Waktu tunggu lama','belum'),(5,5,'2025-06-29 23:02:32','Diskon menarik','dijawab'),(6,6,'2025-06-29 23:02:32','Saya suka fiturnya','belum'),(7,7,'2025-06-29 23:02:32','Harap tambahkan fitur baru','belum'),(8,8,'2025-06-29 23:02:32','Saya tidak puas','dijawab'),(9,9,'2025-06-29 23:02:32','Layanan mantap','belum'),(10,10,'2025-06-29 23:02:32','Berharap lebih cepat','dijawab'),(11,11,'2025-06-29 23:02:32','Sangat berguna','dijawab'),(12,12,'2025-06-29 23:02:32','Lambat dalam login','belum'),(13,13,'2025-06-29 23:02:32','UI/UX nyaman','dijawab'),(14,14,'2025-06-29 23:02:32','Promo kurang banyak','belum'),(15,15,'2025-06-29 23:02:32','Butuh metode pembayaran lain','dijawab'),(16,16,'2025-06-29 23:02:32','Map tidak akurat','belum'),(17,17,'2025-06-29 23:02:32','Bagus tapi mahal','belum'),(18,18,'2025-06-29 23:02:32','Terima kasih','dijawab'),(19,19,'2025-06-29 23:02:32','Fitur keamanan bagus','belum'),(20,20,'2025-06-29 23:02:32','Driver sangat profesional','dijawab');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `license`
--

DROP TABLE IF EXISTS `license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `license` (
  `license_id` int NOT NULL AUTO_INCREMENT,
  `driver_id` int NOT NULL,
  `status_licensi` varchar(200) NOT NULL DEFAULT 'N/A',
  `tanggal_licensi` date NOT NULL,
  `jenis_licensi` varchar(200) NOT NULL DEFAULT 'N/A',
  PRIMARY KEY (`license_id`),
  KEY `Fk_driver_id_license` (`driver_id`),
  CONSTRAINT `Fk_driver_id_license` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `license`
--

LOCK TABLES `license` WRITE;
/*!40000 ALTER TABLE `license` DISABLE KEYS */;
INSERT INTO `license` VALUES (1,1,'aktif','2022-01-15','Sim A'),(2,2,'aktif','2022-06-10','Sim C'),(4,4,'aktif','2023-07-19','Sim C'),(5,5,'aktif','2023-03-25','Sim A'),(7,7,'aktif','2023-09-10','Sim A'),(8,8,'aktif','2022-11-30','Sim C'),(10,10,'aktif','2024-01-01','Sim C'),(11,11,'aktif','2023-05-14','Sim A'),(13,13,'aktif','2024-03-22','Sim A'),(14,14,'aktif','2023-11-05','Sim C'),(16,16,'aktif','2024-06-01','Sim C'),(17,17,'aktif','2022-08-28','Sim A'),(19,19,'aktif','2024-02-12','Sim A'),(20,20,'aktif','2023-10-30','Sim C');
/*!40000 ALTER TABLE `license` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `label` varchar(200) NOT NULL DEFAULT 'N/A',
  `latitude` decimal(10,6) NOT NULL,
  `longitude` decimal(10,6) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `Fk_user_id_location` (`user_id`),
  CONSTRAINT `Fk_user_id_location` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,1,'Rumah',-6.200000,106.816666),(2,2,'Kantor',-6.914744,107.609810),(3,3,'Kos',-7.257472,112.752090),(4,4,'Stasiun',-6.241586,106.992416),(6,6,'Mall',-5.147665,119.432732),(7,7,'Taman',-2.990934,104.756554),(8,8,'Kampus',-7.005145,110.438125),(9,9,'Pasar',-7.801389,110.364722),(10,10,'Terminal',-5.147900,119.432600),(11,11,'Pelabuhan',-2.976100,104.775400),(12,12,'Restoran',-7.001400,110.428900),(13,13,'Pantai',-8.409500,115.188900),(14,14,'Hotel',-0.026300,109.342500),(15,15,'Klinik',0.533300,101.450000),(16,16,'Sekolah',1.474800,124.842100),(17,17,'Stadion',-0.949200,100.354300),(18,18,'Toko',1.144100,104.014500),(19,19,'Masjid',-6.732500,108.552300),(20,20,'Perpustakaan',-7.979700,112.630400);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginhistory`
--

DROP TABLE IF EXISTS `loginhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loginhistory` (
  `login_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `waktu_login` datetime NOT NULL,
  PRIMARY KEY (`login_id`),
  KEY `Fk_user_id_loginhistory` (`user_id`),
  CONSTRAINT `Fk_user_id_loginhistory` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginhistory`
--

LOCK TABLES `loginhistory` WRITE;
/*!40000 ALTER TABLE `loginhistory` DISABLE KEYS */;
INSERT INTO `loginhistory` VALUES (1,1,'2025-06-29 23:02:32'),(2,2,'2025-06-29 23:02:32'),(3,3,'2025-06-29 23:02:32'),(4,4,'2025-06-29 23:02:32'),(5,5,'2025-06-29 23:02:32'),(6,6,'2025-06-29 23:02:32'),(7,7,'2025-06-29 23:02:32'),(8,8,'2025-06-29 23:02:32'),(9,9,'2025-06-29 23:02:32'),(10,10,'2025-06-29 23:02:32'),(11,11,'2025-06-29 23:02:32'),(12,12,'2025-06-29 23:02:32'),(13,13,'2025-06-29 23:02:32'),(14,14,'2025-06-29 23:02:32'),(15,15,'2025-06-29 23:02:32'),(16,16,'2025-06-29 23:02:32'),(17,17,'2025-06-29 23:02:32'),(18,18,'2025-06-29 23:02:32'),(19,19,'2025-06-29 23:02:32'),(20,20,'2025-06-29 23:02:32');
/*!40000 ALTER TABLE `loginhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `notification_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `isi_pesan` varchar(200) NOT NULL DEFAULT 'N/A',
  `waktu_dikirim` timestamp NOT NULL,
  `dibaca_status` enum('dibaca','belum dibaca') NOT NULL DEFAULT 'belum dibaca',
  PRIMARY KEY (`notification_id`),
  KEY `Fk_user_id_notification` (`user_id`),
  CONSTRAINT `Fk_user_id_notification` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (1,1,'Promo baru untukmu!','2025-06-29 16:02:32','belum dibaca'),(2,2,'Perjalanan selesai','2025-06-29 16:02:32','dibaca'),(3,3,'Driver dalam perjalanan','2025-06-29 16:02:32','belum dibaca'),(4,4,'Dapatkan diskon!','2025-06-29 16:02:32','belum dibaca'),(5,5,'Pembayaran berhasil','2025-06-29 16:02:32','dibaca'),(6,6,'Akun login berhasil','2025-06-29 16:02:32','dibaca'),(7,7,'Driver tiba di lokasi','2025-06-29 16:02:32','belum dibaca'),(8,8,'Kode promo berlaku','2025-06-29 16:02:32','dibaca'),(9,9,'Penilaian diterima','2025-06-29 16:02:32','dibaca'),(10,10,'Selesaikan perjalanan anda','2025-06-29 16:02:32','belum dibaca'),(11,11,'Terima kasih telah menggunakan layanan kami','2025-06-29 16:02:32','dibaca'),(12,12,'Perjalanan telah dimulai','2025-06-29 16:02:32','dibaca'),(13,13,'Pembayaran ditolak','2025-06-29 16:02:32','belum dibaca'),(14,14,'Driver membatalkan perjalanan','2025-06-29 16:02:32','dibaca'),(15,15,'Promo eksklusif untuk anda','2025-06-29 16:02:32','belum dibaca'),(16,16,'Saldo dompet bertambah','2025-06-29 16:02:32','dibaca'),(17,17,'Mohon beri rating driver anda','2025-06-29 16:02:32','belum dibaca'),(18,18,'Laporan berhasil dikirim','2025-06-29 16:02:32','dibaca'),(19,19,'Pengaturan akun diperbarui','2025-06-29 16:02:32','dibaca'),(20,20,'Cek perjalanan terakhir anda','2025-06-29 16:02:32','belum dibaca');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `trip_id` int NOT NULL,
  `payment_method_id` int NOT NULL,
  `jumlah` int NOT NULL,
  `status_pembayaran` enum('lunas','belum') NOT NULL DEFAULT 'belum',
  PRIMARY KEY (`payment_id`),
  KEY `Fk_trip_id_payment` (`trip_id`),
  KEY `Fk_payment_method_id` (`payment_method_id`),
  CONSTRAINT `Fk_payment_method_id` FOREIGN KEY (`payment_method_id`) REFERENCES `paymentmethod` (`payment_method_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_trip_id_payment` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,1,1,30000,'lunas'),(2,2,2,40000,'lunas'),(4,4,1,25000,'lunas'),(5,5,3,45000,'lunas'),(7,7,4,20000,'lunas'),(8,8,2,35000,'lunas'),(9,9,1,30000,'lunas'),(11,11,2,50000,'lunas'),(12,12,3,22000,'lunas'),(14,14,1,15000,'lunas'),(15,15,4,37000,'lunas'),(16,16,3,53000,'lunas'),(17,17,2,24000,'lunas'),(18,18,4,33000,'lunas'),(19,19,1,40000,'lunas'),(20,20,2,48000,'lunas');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymentmethod`
--

DROP TABLE IF EXISTS `paymentmethod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paymentmethod` (
  `payment_method_id` int NOT NULL AUTO_INCREMENT,
  `nama_metode` enum('tunai','qris','e-pay','transfer') NOT NULL DEFAULT 'tunai',
  PRIMARY KEY (`payment_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymentmethod`
--

LOCK TABLES `paymentmethod` WRITE;
/*!40000 ALTER TABLE `paymentmethod` DISABLE KEYS */;
INSERT INTO `paymentmethod` VALUES (1,'tunai'),(2,'qris'),(3,'e-pay'),(4,'transfer'),(5,'tunai'),(6,'qris'),(7,'e-pay'),(8,'transfer'),(9,'tunai'),(10,'qris'),(11,'e-pay'),(12,'transfer'),(13,'tunai'),(14,'qris'),(15,'e-pay'),(16,'transfer'),(17,'tunai'),(18,'qris'),(19,'e-pay'),(20,'transfer');
/*!40000 ALTER TABLE `paymentmethod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pricingpolicy`
--

DROP TABLE IF EXISTS `pricingpolicy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pricingpolicy` (
  `policy_id` int NOT NULL AUTO_INCREMENT,
  `dasar_harga` int NOT NULL,
  `per_km` int NOT NULL,
  `per_menit` int NOT NULL,
  PRIMARY KEY (`policy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pricingpolicy`
--

LOCK TABLES `pricingpolicy` WRITE;
/*!40000 ALTER TABLE `pricingpolicy` DISABLE KEYS */;
INSERT INTO `pricingpolicy` VALUES (1,7000,3000,500),(2,5000,2500,400),(3,10000,4000,600),(4,8000,3500,550),(5,6000,2000,450),(6,9000,3800,700),(7,11000,4200,750),(8,7500,3100,520),(9,8500,3300,530),(10,9500,3700,580),(11,10000,3000,500),(12,7000,2700,480),(13,8000,3400,510),(14,6000,2200,470),(15,7500,3100,520),(16,6500,2600,490),(17,7000,2800,500),(18,9000,3900,600),(19,8500,3600,550),(20,9500,4000,580);
/*!40000 ALTER TABLE `pricingpolicy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promocode`
--

DROP TABLE IF EXISTS `promocode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promocode` (
  `promo_id` int NOT NULL AUTO_INCREMENT,
  `kode_promo` varchar(200) NOT NULL DEFAULT 'N/A',
  `diskon` int NOT NULL,
  `batas_berlaku` varchar(200) NOT NULL DEFAULT 'N/A',
  PRIMARY KEY (`promo_id`),
  UNIQUE KEY `kode_promo` (`kode_promo`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promocode`
--

LOCK TABLES `promocode` WRITE;
/*!40000 ALTER TABLE `promocode` DISABLE KEYS */;
INSERT INTO `promocode` VALUES (1,'HEMAT10',10,'2025-07-31'),(2,'GOJEK20',20,'2025-08-15'),(3,'GRAB15',15,'2025-07-10'),(4,'PROMO30',30,'2025-09-01'),(5,'ONGKIR50',50,'2025-07-05'),(6,'RIDEFREE',100,'2025-07-20'),(7,'CASHBACK25',25,'2025-08-01'),(8,'AKHIRTAHUN',40,'2025-12-31'),(9,'HEBOH22',22,'2025-07-25'),(10,'LIBUR60',60,'2025-08-20'),(11,'TRIPHEMAT',18,'2025-09-15'),(12,'JALANBEBAS',35,'2025-10-01'),(13,'DISKONMERDEKA',45,'2025-08-17'),(14,'RAMADHAN50',50,'2025-03-31'),(15,'MUDIKHEMAT',20,'2025-04-10'),(16,'TRAVELMORE',28,'2025-11-11'),(17,'ONGKIRGRATIS',100,'2025-07-06'),(18,'WEEKEND20',20,'2025-07-13'),(19,'BONUSONGKIR',30,'2025-08-05'),(20,'HAPPYRIDES',15,'2025-09-30');
/*!40000 ALTER TABLE `promocode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rating` (
  `rating_id` int NOT NULL AUTO_INCREMENT,
  `trip_id` int NOT NULL,
  `user_id` int NOT NULL,
  `nilai_rating` enum('baik','buruk') NOT NULL DEFAULT 'baik',
  `komentar` text,
  PRIMARY KEY (`rating_id`),
  KEY `Fk_trip_id_rating` (`trip_id`),
  KEY `FK_user_id_rating` (`user_id`),
  CONSTRAINT `Fk_trip_id_rating` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_user_id_rating` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating`
--

LOCK TABLES `rating` WRITE;
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;
INSERT INTO `rating` VALUES (1,1,1,'baik','Pelayanan sangat baik'),(2,2,2,'baik','Sopir ramah'),(3,4,4,'baik','Cepat dan aman'),(4,5,5,'baik','Cukup baik'),(5,7,7,'baik','Driver on-time'),(6,8,8,'baik','Sangat nyaman'),(7,9,9,'baik','Agak lambat'),(8,11,11,'baik','Luar biasa!'),(9,12,12,'baik','Bagus'),(10,14,14,'baik','Driver terbaik'),(11,15,15,'baik','Rapi dan cepat'),(12,16,16,'baik','Baik dan sopan'),(13,17,17,'buruk','Kurang memuaskan'),(14,18,18,'baik','Sopan dan cepat'),(15,19,19,'baik','Memuaskan'),(16,20,20,'baik','Layanan oke'),(17,3,3,'baik','Belum ada ulasan'),(18,6,6,'baik','Belum ada ulasan'),(19,10,10,'baik','Belum ada ulasan'),(20,13,13,'baik','Belum ada ulasan');
/*!40000 ALTER TABLE `rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referal`
--

DROP TABLE IF EXISTS `referal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referal` (
  `referal_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `reffered_user_id` int DEFAULT NULL,
  `kode_refferal` varchar(200) NOT NULL DEFAULT 'N/A',
  `tanggal_penggunaan` date NOT NULL,
  PRIMARY KEY (`referal_id`),
  UNIQUE KEY `kode_refferal` (`kode_refferal`),
  KEY `Fk_user_id_referal` (`user_id`),
  KEY `Fk_reffered_user_id` (`reffered_user_id`),
  CONSTRAINT `Fk_reffered_user_id` FOREIGN KEY (`reffered_user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_user_id_referal` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referal`
--

LOCK TABLES `referal` WRITE;
/*!40000 ALTER TABLE `referal` DISABLE KEYS */;
INSERT INTO `referal` VALUES (1,1,2,'REF001','2025-06-01'),(2,3,4,'REF002','2025-06-02'),(3,5,6,'REF003','2025-06-03'),(4,7,8,'REF004','2025-06-04'),(5,9,10,'REF005','2025-06-05'),(6,11,12,'REF006','2025-06-06'),(7,13,14,'REF007','2025-06-07'),(8,15,16,'REF008','2025-06-08'),(9,17,18,'REF009','2025-06-09'),(10,19,20,'REF010','2025-06-10'),(11,2,1,'REF011','2025-06-11'),(12,4,3,'REF012','2025-06-12'),(13,6,5,'REF013','2025-06-13'),(14,8,7,'REF014','2025-06-14'),(15,10,9,'REF015','2025-06-15'),(16,12,11,'REF016','2025-06-16'),(17,14,13,'REF017','2025-06-17'),(18,16,15,'REF018','2025-06-18'),(19,18,17,'REF019','2025-06-19'),(20,20,19,'REF020','2025-06-20');
/*!40000 ALTER TABLE `referal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report` (
  `report_id` int NOT NULL AUTO_INCREMENT,
  `trip_id` int NOT NULL,
  `user_id` int NOT NULL,
  `isi_laporan` text,
  `waktu` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`report_id`),
  KEY `Fk_user_id_report` (`user_id`),
  KEY `Fk_trip_id_report` (`trip_id`),
  CONSTRAINT `Fk_trip_id_report` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_user_id_report` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES (1,1,1,'Driver ugal-ugalan','2025-06-29 16:02:32'),(2,2,2,'Biaya tidak sesuai','2025-06-29 16:02:32'),(3,3,3,'Promo tidak bisa digunakan','2025-06-29 16:02:32'),(4,4,4,'Perjalanan dibatalkan sepihak','2025-06-29 16:02:32'),(5,5,5,'Driver telat','2025-06-29 16:02:32'),(6,6,6,'Mobil bau asap rokok','2025-06-29 16:02:32'),(7,7,7,'Sopir tidak ramah','2025-06-29 16:02:32'),(8,8,8,'Waktu tempuh terlalu lama','2025-06-29 16:02:32'),(9,9,9,'Aplikasi crash saat booking','2025-06-29 16:02:32'),(10,10,10,'Lokasi tujuan salah','2025-06-29 16:02:32'),(11,11,11,'Rute terlalu jauh','2025-06-29 16:02:32'),(12,12,12,'Perjalanan tidak sesuai estimasi','2025-06-29 16:02:32'),(13,13,13,'Pembatalan mendadak','2025-06-29 16:02:32'),(14,14,14,'Diskon tidak masuk','2025-06-29 16:02:32'),(15,15,15,'Driver tidak tahu rute','2025-06-29 16:02:32'),(16,16,16,'Kendaraan tidak layak','2025-06-29 16:02:32'),(17,17,17,'Driver tidak datang','2025-06-29 16:02:32'),(18,18,18,'Pengemudi melanggar lalu lintas','2025-06-29 16:02:32'),(19,19,19,'Aplikasi lambat','2025-06-29 16:02:32'),(20,20,20,'Peta tidak akurat','2025-06-29 16:02:32');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rider`
--

DROP TABLE IF EXISTS `rider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rider` (
  `rider_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `no_telpn_rider` varchar(200) NOT NULL DEFAULT 'N/A',
  `lokasi_rider` varchar(200) NOT NULL DEFAULT 'N/A',
  PRIMARY KEY (`rider_id`),
  UNIQUE KEY `no_telpn_rider` (`no_telpn_rider`),
  KEY `Fk_user_id_rider` (`user_id`),
  CONSTRAINT `Fk_user_id_rider` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rider`
--

LOCK TABLES `rider` WRITE;
/*!40000 ALTER TABLE `rider` DISABLE KEYS */;
INSERT INTO `rider` VALUES (1,1,'0812-7654-3210','Jakarta'),(2,2,'+62 821 9892 2016','Cempaka'),(3,3,'0856-7788-9900','Surabaya'),(4,4,'0813-1122-3344','Medan'),(5,5,'0813-4455-6677','Yogyarkarta'),(6,6,'0822-9988-7766','Palembang'),(7,7,'0851-3344-5566','Palembang'),(8,8,'0817-5566-7788','Makasar'),(9,9,'0899-1234-7788','Makasar'),(10,10,'0877-8888-1234','Pontianak'),(11,11,'0812-1122-3344','Malang'),(12,12,'0822-7788-6655','Pekanbaru'),(13,13,'0852-9911-2233','Batam'),(14,14,'0853-3344-2211','Padang'),(15,15,'0813-8899-7766','Denpasar'),(16,16,'0878-5566-3344','Banjarmasin'),(17,17,'0856-1122-9988','Manado'),(18,18,'08881-6677-1234','Tangerang'),(19,19,'0814-3344-8899','Cirebon'),(20,20,'0833-4455-1122','Bogor');
/*!40000 ALTER TABLE `rider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supportcategory`
--

DROP TABLE IF EXISTS `supportcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supportcategory` (
  `support_category_id` int NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(200) NOT NULL DEFAULT 'N/A',
  PRIMARY KEY (`support_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supportcategory`
--

LOCK TABLES `supportcategory` WRITE;
/*!40000 ALTER TABLE `supportcategory` DISABLE KEYS */;
INSERT INTO `supportcategory` VALUES (1,'Akun'),(2,'Pembayaran'),(3,'Perjalanan'),(4,'Promo'),(5,'Lainnya'),(6,'Akun'),(7,'Pembayaran'),(8,'Perjalanan'),(9,'Promo'),(10,'Lainnya'),(11,'Akun'),(12,'Pembayaran'),(13,'Perjalanan'),(14,'Promo'),(15,'Lainnya'),(16,'Akun'),(17,'Pembayaran'),(18,'Perjalanan'),(19,'Promo'),(20,'Lainnya');
/*!40000 ALTER TABLE `supportcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supportticket`
--

DROP TABLE IF EXISTS `supportticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supportticket` (
  `ticket_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `support_category_id` int NOT NULL,
  `isi_ticket` varchar(200) NOT NULL DEFAULT 'N/A',
  `status_ticket` enum('baru','proses','selesai') NOT NULL DEFAULT 'selesai',
  PRIMARY KEY (`ticket_id`),
  KEY `Fk_user_id_supportticket` (`user_id`),
  KEY `Fk_support_category_id` (`support_category_id`),
  CONSTRAINT `Fk_support_category_id` FOREIGN KEY (`support_category_id`) REFERENCES `supportcategory` (`support_category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_user_id_supportticket` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supportticket`
--

LOCK TABLES `supportticket` WRITE;
/*!40000 ALTER TABLE `supportticket` DISABLE KEYS */;
INSERT INTO `supportticket` VALUES (1,1,1,'Tidak bisa bayar','baru'),(2,2,2,'Driver kasar','proses'),(3,3,3,'Promo tidak bisa dipakai','selesai'),(4,4,4,'Aplikasi error','proses'),(5,5,5,'Ingin kasih saran','baru'),(6,6,6,'Refund saya belum masuk','selesai'),(7,7,7,'Dana belum kembali','proses'),(8,8,8,'Perjalanan saya tidak sesuai','selesai'),(9,9,9,'Driver tidak bisa temukan lokasi','baru'),(10,10,10,'Keluhan umum','baru'),(11,11,11,'Tidak bisa login','proses'),(12,12,12,'Tidak bisa pesan','selesai'),(13,13,13,'Saya beri rating buruk','proses'),(14,14,14,'Bayar gagal','baru'),(15,15,15,'Akun saya dihapus?','proses'),(16,16,16,'Trip tidak sesuai','selesai'),(17,17,17,'Driver telat','baru'),(18,18,18,'Tidak ada driver tersedia','selesai'),(19,19,19,'Promo saya hilang','proses'),(20,20,20,'Poin tidak masuk','selesai');
/*!40000 ALTER TABLE `supportticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trip`
--

DROP TABLE IF EXISTS `trip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trip` (
  `trip_id` int NOT NULL AUTO_INCREMENT,
  `rider_id` int NOT NULL,
  `driver_id` int NOT NULL,
  `trip_status_id` int NOT NULL,
  `promo_id` int NOT NULL,
  `waktu_mulai` datetime NOT NULL,
  `waktu_selesai` datetime NOT NULL,
  `biaya` decimal(10,2) NOT NULL,
  `lokasi_awal` varchar(200) NOT NULL DEFAULT 'N/A',
  `lokasi_tujuan` varchar(200) NOT NULL DEFAULT 'N/A',
  PRIMARY KEY (`trip_id`),
  KEY `Fk_rider_id_trip` (`rider_id`),
  KEY `Fk_driver_id_trip` (`driver_id`),
  KEY `Fk_trip_status_id` (`trip_status_id`),
  KEY `Fk_promo_id_trip` (`promo_id`),
  CONSTRAINT `Fk_driver_id_trip` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_promo_id_trip` FOREIGN KEY (`promo_id`) REFERENCES `promocode` (`promo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_rider_id_trip` FOREIGN KEY (`rider_id`) REFERENCES `rider` (`rider_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_trip_status_id` FOREIGN KEY (`trip_status_id`) REFERENCES `tripstatus` (`trip_status_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trip`
--

LOCK TABLES `trip` WRITE;
/*!40000 ALTER TABLE `trip` DISABLE KEYS */;
INSERT INTO `trip` VALUES (1,1,1,1,1,'2025-06-01 08:00:00','2025-06-01 08:45:00',25000.00,'Jakarta','Depok'),(2,2,2,2,2,'2025-06-02 09:15:00','2025-06-02 09:50:00',32000.00,'Bandung','Cimahi'),(3,3,3,3,3,'2025-06-03 14:00:00','2025-06-03 14:35:00',28000.00,'Surabaya','Sidoarjo'),(4,4,4,4,4,'2025-06-04 07:00:00','2025-06-04 07:40:00',30000.00,'Medan','Binjai'),(5,5,5,5,5,'2025-06-05 17:30:00','2025-06-05 18:10:00',27000.00,'Yogyakarta','Sleman'),(6,6,6,6,6,'2025-06-06 11:20:00','2025-06-06 12:05:00',29000.00,'Palembang','Plaju'),(7,7,7,7,7,'2025-06-07 12:00:00','2025-06-07 12:45:00',31000.00,'Palembang','Jakabaring'),(8,8,8,8,8,'2025-06-08 13:00:00','2025-06-08 13:50:00',33000.00,'Makasar','Gowa'),(9,9,9,9,9,'2025-06-09 10:00:00','2025-06-09 10:40:00',26000.00,'Makasar','Maros'),(10,10,10,10,10,'2025-06-10 19:00:00','2025-06-10 19:35:00',24000.00,'Pontianak','Sungai Raya'),(11,11,11,11,11,'2025-06-11 08:10:00','2025-06-11 08:55:00',27000.00,'Malang','Batu'),(12,12,12,12,12,'2025-06-12 16:00:00','2025-06-12 16:50:00',35000.00,'Pekanbaru','Simpang Tiga'),(13,13,13,13,13,'2025-06-13 07:45:00','2025-06-13 08:30:00',26500.00,'Batam','Nongsa'),(14,14,14,14,14,'2025-06-14 15:30:00','2025-06-14 16:15:00',27500.00,'Padang','Lubuk Begalung'),(15,15,15,15,15,'2025-06-15 10:30:00','2025-06-15 11:20:00',34000.00,'Denpasar','Kuta'),(16,16,16,16,16,'2025-06-16 13:20:00','2025-06-16 14:00:00',29500.00,'Banjarmasin','Banjarbaru'),(17,17,17,17,17,'2025-06-17 18:00:00','2025-06-17 18:40:00',31000.00,'Manado','Tomohon'),(18,18,18,18,18,'2025-06-18 09:00:00','2025-06-18 09:45:00',28500.00,'Tangerang','Serpong'),(19,19,19,19,19,'2025-06-19 06:30:00','2025-06-19 07:15:00',25000.00,'Cirebon','Majalengka'),(20,20,20,20,20,'2025-06-20 08:30:00','2025-06-20 09:15:00',29500.00,'Bogor','Depok');
/*!40000 ALTER TABLE `trip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trippromo`
--

DROP TABLE IF EXISTS `trippromo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trippromo` (
  `trip_promo_id` int NOT NULL AUTO_INCREMENT,
  `trip_id` int NOT NULL,
  `promo_id` int NOT NULL,
  `jumlah_diskon` int DEFAULT NULL,
  PRIMARY KEY (`trip_promo_id`),
  KEY `Fk_trip_id_trippromo` (`trip_id`),
  KEY `fk_promo_id_trippromo` (`promo_id`),
  CONSTRAINT `fk_promo_id_trippromo` FOREIGN KEY (`promo_id`) REFERENCES `promocode` (`promo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_trip_id_trippromo` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trippromo`
--

LOCK TABLES `trippromo` WRITE;
/*!40000 ALTER TABLE `trippromo` DISABLE KEYS */;
INSERT INTO `trippromo` VALUES (1,1,1,3000),(3,4,4,3750),(5,7,7,2000),(7,9,9,1500),(9,12,12,2200),(10,14,14,3000),(13,17,17,3600),(14,18,18,4950),(15,19,19,2000),(16,20,20,4800),(18,6,6,1500),(20,13,13,1300);
/*!40000 ALTER TABLE `trippromo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `triproute`
--

DROP TABLE IF EXISTS `triproute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `triproute` (
  `trip_route_id` int NOT NULL AUTO_INCREMENT,
  `trip_id` int NOT NULL,
  `titik_awal` varchar(200) NOT NULL DEFAULT 'N/A',
  `titik_tengah` varchar(200) NOT NULL DEFAULT 'N/A',
  `titik_akhir` varchar(200) NOT NULL DEFAULT 'N/A',
  PRIMARY KEY (`trip_route_id`),
  KEY `Fk_trip_id_triproute` (`trip_id`),
  CONSTRAINT `Fk_trip_id_triproute` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `triproute`
--

LOCK TABLES `triproute` WRITE;
/*!40000 ALTER TABLE `triproute` DISABLE KEYS */;
INSERT INTO `triproute` VALUES (1,1,'Jakarta','Cawang','Depok'),(2,2,'Bandung','Cimahi','Bekasi'),(3,3,'Surabaya','Wonokromo','Sidoarjo'),(4,4,'Bekasi','Cibitung','Jakarta'),(5,5,'Medan','Tuntungan','Binjai'),(6,6,'Makassar','Panakkukang','Gowa'),(7,7,'Palembang','Seberang Ulu','Plaju'),(8,8,'Semarang','Tembalang','Ungaran'),(9,9,'Yogyakarta','Kaliurang','Sleman'),(10,10,'Makassar','Somba Opu','Maros'),(11,11,'Palembang','Jakabaring','Banyuasin'),(12,12,'Semarang','Gajahmungkur','Demak'),(13,13,'Bali','Sanur','Gianyar'),(14,14,'Pontianak','Pontianak Selatan','Singkawang'),(15,15,'Pekanbaru','Tampan','Bangkinang'),(16,16,'Manado','Sario','Bitung'),(17,17,'Padang','Padang Timur','Bukittinggi'),(18,18,'Batam','Batu Aji','Tanjungpinang'),(19,19,'Cirebon','Kejaksan','Indramayu'),(20,20,'Malang','Klojen','Blitar');
/*!40000 ALTER TABLE `triproute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tripstatus`
--

DROP TABLE IF EXISTS `tripstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tripstatus` (
  `trip_status_id` int NOT NULL AUTO_INCREMENT,
  `nama_status` enum('aktif','dibatalkan','selesai') NOT NULL DEFAULT 'dibatalkan',
  PRIMARY KEY (`trip_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tripstatus`
--

LOCK TABLES `tripstatus` WRITE;
/*!40000 ALTER TABLE `tripstatus` DISABLE KEYS */;
INSERT INTO `tripstatus` VALUES (1,'aktif'),(2,'dibatalkan'),(3,'selesai'),(4,'aktif'),(5,'dibatalkan'),(6,'selesai'),(7,'aktif'),(8,'dibatalkan'),(9,'selesai'),(10,'aktif'),(11,'dibatalkan'),(12,'selesai'),(13,'aktif'),(14,'aktif'),(15,'dibatalkan'),(16,'selesai'),(17,'aktif'),(18,'dibatalkan'),(19,'selesai'),(20,'aktif'),(21,'dibatalkan'),(22,'selesai'),(23,'aktif'),(24,'dibatalkan'),(25,'selesai'),(26,'aktif');
/*!40000 ALTER TABLE `tripstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(200) NOT NULL DEFAULT 'N/A',
  `no_tlpn_user` varchar(200) NOT NULL DEFAULT 'N/A',
  `lokasi_user` varchar(200) NOT NULL DEFAULT 'N/A',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `no_tlpn_user` (`no_tlpn_user`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Budi Kurniawan','0812-1234-5678','Medan'),(2,'Budi Santoso','0821-8765-4321','Bandung'),(3,'Citra Dewi','0852-3333-5566','Surabaya'),(4,'Deni Pratama','0838-1122-3344','Medan'),(6,'Farhan Hidayat','0851-6677-8899','Palembang'),(7,'Gita Ramahani','0851-6677-8890','Semarang'),(8,'Hendra Wijaya','0812-4455-6677','Makasar'),(9,'Intan Maulinda','0899-1234-5678','Balikpapan'),(10,'Joko Susilo','0877-2345-6789','Pontianak'),(11,'Kiki Amelia','0812-3344-5566','Malang'),(12,'Lukman Hakim','0822-7788-9900','Pekanbaru'),(13,'Maya Putri','0831-2233-4455','Batam'),(14,'Nando Siregar','0853-1122-3344','Padang'),(15,'Olivia Natalia','0819-6677-8899','Denpasar'),(16,'Pandu Wijaya','0878-5566-7788','Banjarmasin'),(17,'Qori Alamsyah','0856-9988-1122','Manado'),(18,'Rina Kartika','0881-2233-4455','Tangerang'),(19,'Surya Dharma','0814-5566-7788','Cirebon'),(20,'Tasya Adina','0833-6677-8899','Bogor');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicle`
--

DROP TABLE IF EXISTS `vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle` (
  `vehicle_id` int NOT NULL AUTO_INCREMENT,
  `driver_id` int NOT NULL,
  `vehicle_type_id` int NOT NULL,
  `jenis` enum('UberX','UberXL') NOT NULL DEFAULT 'UberX',
  PRIMARY KEY (`vehicle_id`),
  KEY `Fk_driver_id_vehicle` (`driver_id`),
  KEY `Fk_vehicle_type_id` (`vehicle_type_id`),
  CONSTRAINT `Fk_driver_id_vehicle` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Fk_vehicle_type_id` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicletype` (`vehicle_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle`
--

LOCK TABLES `vehicle` WRITE;
/*!40000 ALTER TABLE `vehicle` DISABLE KEYS */;
INSERT INTO `vehicle` VALUES (1,1,1,'UberXL'),(2,2,2,'UberXL'),(3,3,3,'UberX'),(4,4,4,'UberX'),(5,5,5,'UberXL'),(6,6,6,'UberX'),(7,7,7,'UberXL'),(8,8,8,'UberX'),(9,9,9,'UberXL'),(10,10,10,'UberX'),(11,11,11,'UberX'),(12,12,12,'UberXL'),(13,13,13,'UberX'),(14,14,14,'UberX'),(15,15,15,'UberXL'),(16,16,16,'UberX'),(17,17,17,'UberXL'),(18,18,18,'UberX'),(19,19,19,'UberXL'),(20,20,20,'UberX');
/*!40000 ALTER TABLE `vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicletype`
--

DROP TABLE IF EXISTS `vehicletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicletype` (
  `vehicle_type_id` int NOT NULL AUTO_INCREMENT,
  `tipe_kendaraan` enum('motor','mobil') NOT NULL DEFAULT 'motor',
  PRIMARY KEY (`vehicle_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicletype`
--

LOCK TABLES `vehicletype` WRITE;
/*!40000 ALTER TABLE `vehicletype` DISABLE KEYS */;
INSERT INTO `vehicletype` VALUES (1,'mobil'),(2,'mobil'),(3,'motor'),(4,'mobil'),(5,'motor'),(6,'mobil'),(7,'motor'),(8,'mobil'),(9,'motor'),(10,'mobil'),(11,'motor'),(12,'mobil'),(13,'motor'),(14,'mobil'),(15,'motor'),(16,'mobil'),(17,'motor'),(18,'mobil'),(19,'motor'),(20,'mobil');
/*!40000 ALTER TABLE `vehicletype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_info_device_4`
--

DROP TABLE IF EXISTS `view_info_device_4`;
/*!50001 DROP VIEW IF EXISTS `view_info_device_4`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_info_device_4` AS SELECT 
 1 AS `user_id`,
 1 AS `nama_user`,
 1 AS `device_type`,
 1 AS `os_version`,
 1 AS `last_login`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_info_review_user_3`
--

DROP TABLE IF EXISTS `view_info_review_user_3`;
/*!50001 DROP VIEW IF EXISTS `view_info_review_user_3`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_info_review_user_3` AS SELECT 
 1 AS `user_id`,
 1 AS `nama_user`,
 1 AS `nilai_rating`,
 1 AS `komentar`,
 1 AS `waktu_login`,
 1 AS `submitted_at`,
 1 AS `feedback_text`,
 1 AS `response_status`,
 1 AS `trip_id`,
 1 AS `isi_laporan`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_info_trip_2`
--

DROP TABLE IF EXISTS `view_info_trip_2`;
/*!50001 DROP VIEW IF EXISTS `view_info_trip_2`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_info_trip_2` AS SELECT 
 1 AS `trip_id`,
 1 AS `trip_route_id`,
 1 AS `titik_awal`,
 1 AS `titik_akhir`,
 1 AS `promo_id`,
 1 AS `jumlah_diskon`,
 1 AS `nama_metode`,
 1 AS `jumlah`,
 1 AS `status_pembayaran`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_info_user_and_driver_1`
--

DROP TABLE IF EXISTS `view_info_user_and_driver_1`;
/*!50001 DROP VIEW IF EXISTS `view_info_user_and_driver_1`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_info_user_and_driver_1` AS SELECT 
 1 AS `user_id`,
 1 AS `nama_user`,
 1 AS `no_tlpn_user`,
 1 AS `lokasi_user`,
 1 AS `driver_id`,
 1 AS `no_telp_driver`,
 1 AS `lokasi_driver`,
 1 AS `jenis`,
 1 AS `tipe_kendaraan`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_info_device_4`
--

/*!50001 DROP VIEW IF EXISTS `view_info_device_4`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_info_device_4` AS select `u`.`user_id` AS `user_id`,`u`.`nama_user` AS `nama_user`,`d`.`device_type` AS `device_type`,`d`.`os_version` AS `os_version`,`d`.`last_login` AS `last_login` from ((`user` `u` join `notification` `n` on((`n`.`user_id` = `u`.`user_id`))) join `device` `d` on((`d`.`user_id` = `u`.`user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_info_review_user_3`
--

/*!50001 DROP VIEW IF EXISTS `view_info_review_user_3`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_info_review_user_3` AS select `u`.`user_id` AS `user_id`,`u`.`nama_user` AS `nama_user`,`r`.`nilai_rating` AS `nilai_rating`,`r`.`komentar` AS `komentar`,`l`.`waktu_login` AS `waktu_login`,`f`.`submitted_at` AS `submitted_at`,`f`.`feedback_text` AS `feedback_text`,`f`.`response_status` AS `response_status`,`p`.`trip_id` AS `trip_id`,`p`.`isi_laporan` AS `isi_laporan` from ((((`user` `u` join `rating` `r` on((`r`.`user_id` = `u`.`user_id`))) join `loginhistory` `l` on((`l`.`user_id` = `u`.`user_id`))) join `feedback` `f` on((`f`.`user_id` = `u`.`user_id`))) join `report` `p` on((`p`.`user_id` = `u`.`user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_info_trip_2`
--

/*!50001 DROP VIEW IF EXISTS `view_info_trip_2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_info_trip_2` AS select `r`.`trip_id` AS `trip_id`,`r`.`trip_route_id` AS `trip_route_id`,`r`.`titik_awal` AS `titik_awal`,`r`.`titik_akhir` AS `titik_akhir`,`o`.`promo_id` AS `promo_id`,`o`.`jumlah_diskon` AS `jumlah_diskon`,`m`.`nama_metode` AS `nama_metode`,`p`.`jumlah` AS `jumlah`,`p`.`status_pembayaran` AS `status_pembayaran` from ((((`trip` `t` join `payment` `p` on((`t`.`trip_id` = `p`.`trip_id`))) join `paymentmethod` `m` on((`m`.`payment_method_id` = `p`.`payment_method_id`))) join `triproute` `r` on((`r`.`trip_id` = `t`.`trip_id`))) join `trippromo` `o` on((`o`.`trip_id` = `t`.`trip_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_info_user_and_driver_1`
--

/*!50001 DROP VIEW IF EXISTS `view_info_user_and_driver_1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_info_user_and_driver_1` AS select `u`.`user_id` AS `user_id`,`u`.`nama_user` AS `nama_user`,`u`.`no_tlpn_user` AS `no_tlpn_user`,`u`.`lokasi_user` AS `lokasi_user`,`d`.`driver_id` AS `driver_id`,`d`.`no_telp_driver` AS `no_telp_driver`,`d`.`lokasi_driver` AS `lokasi_driver`,`v`.`jenis` AS `jenis`,`t`.`tipe_kendaraan` AS `tipe_kendaraan` from ((((`driver` `d` join `user` `u` on((`d`.`user_id` = `u`.`user_id`))) join `location` `l` on((`u`.`user_id` = `l`.`user_id`))) join `vehicle` `v` on((`d`.`driver_id` = `v`.`driver_id`))) join `vehicletype` `t` on((`t`.`vehicle_type_id` = `v`.`vehicle_type_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-29 23:14:24
